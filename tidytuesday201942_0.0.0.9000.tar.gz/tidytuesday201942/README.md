
<!-- README.md is generated from README.Rmd. Please edit that file -->

# tidytuesday201942

<!-- badges: start -->

[![Lifecycle:
experimental](https://img.shields.io/badge/lifecycle-experimental-orange.svg)](https://www.tidyverse.org/lifecycle/#experimental)
<!-- badges: end -->

The goal of tidytuesday201942 is to visualize data from TIdy Tuesday
2019, October 15th.

Available at <https://connect.thinkr.fr/tidytuesday201942>

Please note that the ‘tidytuesday201942’ project is released with a
[Contributor Code of Conduct](CODE_OF_CONDUCT.md). By contributing to
this project, you agree to abide by its terms.
