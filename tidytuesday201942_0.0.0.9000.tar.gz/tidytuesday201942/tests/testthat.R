library(testthat)
library(tidytuesday201942)

test_check("tidytuesday201942")
